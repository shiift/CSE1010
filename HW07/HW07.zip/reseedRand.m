function reseedRand
% This function resets the random number generator to make a 'more' random
% number.
% Use: reseedRand
    rng('shuffle')
end