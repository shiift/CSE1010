function c = sendCharParity(a,c)
    fprintf('sendChar sending char %c \n',c)
    binVector = char2bin(c);
    binVector = appendParity(binVector,0);
    for i = 1:length(binVector)
        sendBit(a,binVector(i));
        fprintf('%g',binVector(i))
    end
    fprintf('\n')
    check = receiveBit(a);
    if check == 0
        c = sendCharParity(a,c);
    end
end