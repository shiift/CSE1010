function sendBit(a,bit)
    global LO_DURATION
    global HI_DURATION
    global SPACE_DURATION
    switch bit
        case 0
            led5(a, 9);
            pause(LO_DURATION);
            led5(a, 0);
            pause(SPACE_DURATION);
        case 1
            led5(a, 9);
            pause(HI_DURATION);
            led5(a, 0);
            pause(SPACE_DURATION);
    end
end