s = recvString(a);
sendString(a,s)