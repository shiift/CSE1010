t = tic;

sendString(a,'abc')
recvString(a);

roundTripTime = toc(t)