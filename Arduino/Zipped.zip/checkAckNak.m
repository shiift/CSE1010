function [bit status] = checkAckNak(a)
    global LO_DURATION
    global HI_DURATION
    global LO_LEVEL
    global HI_LEVEL
    avgLevel = (HI_LEVEL + LO_LEVEL)/2;
    avgDuration = (HI_DURATION + LO_DURATION)/2;
    t = tic;
    status = 0;
    while true
        lightLevel = readLightLevel(a);
        if lightLevel > avgLevel
            tic
            break
        end
        if toc(t) > 2
            status = 1;
            bit = 2;
            return
        end
    end
    while true
        lightLevel = readLightLevel(a);
        if lightLevel < avgLevel
            times = toc;
            break
        end
    end
    if times > avgDuration
        bit = 1;
    else
        bit = 0;
    end
end