function c = recvCharParity(a)
    for i = 1:9
        [binVector(i) status] = checkAckNak(a);
        fprintf('%g',binVector(i))
        if status == 1
            binVector = [0 1 0 0 0 0 0 0 0];
            break
        end
    end
    fprintf('\n')
    c = bin2char(binVector(1:8));
    fprintf('recvChar got char %c \n',c)
    
    check = checkParity(binVector,0);
    if check == 1
        sendBit(a,1)
    else
        sendBit(a,0)
        c = recvCharParity(a);
    end
end