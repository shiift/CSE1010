function setupGlobals
  % Defines G to be a global variable and give it a value:
  % Use: setupGlobals
    global G
    G = -9.8;
end