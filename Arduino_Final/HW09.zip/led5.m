function led5(a,value)
    value = num2str(value);
    fwrite(a, value);
end