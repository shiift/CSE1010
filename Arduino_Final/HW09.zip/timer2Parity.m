s = recvStringParity(a);
sendStringParity(a,s);