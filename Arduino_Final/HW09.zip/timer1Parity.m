t = tic;

sendStringParity(a,'abc');
recvStringParity(a);

roundTripTime = toc(t)